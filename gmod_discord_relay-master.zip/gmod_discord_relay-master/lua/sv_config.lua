Discord = {
	['webhook'] = "paste_url",
	
	['hookname'] = "Gmod Relay",

	['readChannelID'] = "channel_ID_for_get_msg",

	['botToken'] = 'token',

	["botPrefix"] = ".",

	-- For developers (logs)
	['debug'] = false,

	-- Don't touch!
	['commands'] = {}
}
